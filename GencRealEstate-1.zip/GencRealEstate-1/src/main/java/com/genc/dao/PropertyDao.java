package com.genc.dao;

import java.util.List;

import com.genc.entity.Property;
import com.genc.pojo.PropertyCriteria;
/********************************************************************************************************
 * @author 		SANJAY DAS
 * Description	It is an interface of service layer that provides various methods for its implementation class
 * @version		1.0
 * @since	24-MAR-2021 
 ********************************************************************************************************/
public interface PropertyDao {


	public List<Property> fetchPropertyByCriteria(PropertyCriteria criteria);
}
