package com.genc.service;

import java.util.List;

import com.genc.entity.Property;
import com.genc.exception.PropertyNotFoundException;
import com.genc.pojo.PropertyCriteria;

/*************************************************************************************************************
 * @author 		SANJAY DAS
 * Description	It is an interface of service layer of property module that provides various methods for its implementation class
 * @version		1.0
 * @since		25-MAR-2021 
 **************************************************************************************************************/

public interface IPropertyService {

	public Property addProperty(Property property);

	public Property editProperty(Property property);

	public Property removeProperty(int propId) throws PropertyNotFoundException;

	public Property viewProperty(int propId) throws PropertyNotFoundException;

	public List<Property> listAllProperties();

	public List<Property> ListPropertyByCriteria(PropertyCriteria criteria);

}
