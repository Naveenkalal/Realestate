package com.genc.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.genc.entity.User;
import com.genc.exception.PasswordNotMatchException;
import com.genc.exception.UserNotFoundException;

/*************************************************************************************************************
 * @author 		Kruthika K
 * Description	It is an interface of service layer that provides various methods for its implementation class
 * @version		1.0
 * @since		13-APR-2022
 **************************************************************************************************************/

@Service
public interface IUserService {


	boolean signIn(User user) throws UserNotFoundException;

	boolean signOut(User user) throws UserNotFoundException;

	User changePassword(int userid, User user) throws UserNotFoundException, PasswordNotMatchException;
	
	List<User> getAllUsers();
	
	User getUserById(int userId);
	
	User getUserByEmail(String email);
 
}
