package com.genc.service;

import java.util.List;
import com.genc.entity.Deal;
import com.genc.exception.DealNotAvailableException;

/*************************************************************************************************************
 * @author 		PATHAN ARSHIYA SHAHINA
 * Description	It is an interface of service layer that provides various methods for its implementation class
 * @version		1.0
 * @since		25-MAR-2021 
 **************************************************************************************************************/

public interface IDealService {

	public Deal addDeal(Deal d) throws DealNotAvailableException;

	public List<Deal> listAllDeals();
}
