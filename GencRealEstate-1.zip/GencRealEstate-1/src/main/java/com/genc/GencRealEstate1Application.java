package com.genc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GencRealEstate1Application {

	public static void main(String[] args) {
		SpringApplication.run(GencRealEstate1Application.class, args);
	}

}
